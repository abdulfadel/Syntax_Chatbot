module.exports = {
    name: 'website',
    description: "Website link",
    execute(message, args){
        message.channel.send('web');  
    }

}