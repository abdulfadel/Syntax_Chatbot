module.exports = {
    name: 'js_var',
    description: " What is a Variable? .",
    execute(message, args, Discord){ 
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#CB24F9')
        .setTitle('JavaScript Variables | MORE')
        .setURL('https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/var')
        .setDescription('var declarations, wherever they occur, are processed before any code is executed. This is called hoisting and is discussed further below.The scope of a variable declared with var is its current execution context and closures thereof, which is either the enclosing function and functions declared within it, or, for variables declared outside any function, global. Duplicate variable declarations using var will not trigger an error, even in strict mode, and the variable will not lose its value, unless another assignment is performed.')
        /*.addFields(
            {name: '', value: ''},
            {name: '', value: ''},
            {name: '', value: ''},
            {name: '', value: ''},
        ) */
        .setImage("https://www.tutsmake.com/wp-content/uploads/2020/05/JavaScript-Variable-Example.jpeg")
        .setFooter('SyntaxAI | JavaScript Variables')

        message.channel.send({embeds: [newEmbed]})


        
    }

}